-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2022 at 12:13 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `plannergo`
--

-- --------------------------------------------------------

--
-- Table structure for table `plannergo_notes`
--

CREATE TABLE `plannergo_notes` (
  `notesid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `workspaceid` int(11) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `userid` int(10) NOT NULL,
  `creationdate` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plannergo_notes`
--

INSERT INTO `plannergo_notes` (`notesid`, `title`, `workspaceid`, `description`, `userid`, `creationdate`) VALUES
(14, 'ghjkl', 22, 'ghjkjhg dfgyhuio', 39, '0000-00-00 00:00:00.000000'),
(15, 'ghjkl', 22, 'ghjkjhg dfgyhuio', 39, '0000-00-00 00:00:00.000000'),
(16, 'sedf', 22, 'sdgfh', 39, '2022-11-23 19:33:05.000000'),
(24, 'maths to do list', 21, 'chapter 1 ', 37, '2022-11-23 19:50:35.000000'),
(27, 'project mng', 20, 'all about projects', 37, '2022-11-23 22:29:57.000000');

-- --------------------------------------------------------

--
-- Table structure for table `plannergo_users`
--

CREATE TABLE `plannergo_users` (
  `userid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plannergo_users`
--

INSERT INTO `plannergo_users` (`userid`, `username`, `email`, `password`) VALUES
(25, 'param', 'param@gmail.com', '$2y$10$EgEu8TgMiJjyOyZMGHsaAeKBIoiGVVc52s9kkEXkmjpK5POmqtCNi'),
(26, 'jashan', 'jashan@gmail.com', '$2y$10$/03U/RiqGSQUlxZPNGCGyerTmINP1ou0afjxekgI.a5rO9AimdybC'),
(27, 'rohanpreet', 'rohan@gmail.comm', '$2y$10$xAfuTNCHENLub17iFxb/eOcJssqWix5JJz6YpUTuj2Difeu.SJJc2'),
(32, 'soham', 'soham@g.f', '$2y$10$oSupafZqofeCS3tvnWvZZ.tIMy.35Dunj1b0xoEeq0he/5LeO8AJm'),
(36, 'admin', 'admin@gmail.com', '$2y$10$jREntqoIuO.X/28Zd0H9IegcvVjgmMMmtxISiQTRnvock1DF1Fu8i'),
(37, 'tobiii', 'tobi@gmail.com', '$2y$10$YyrxmzWvhtffxFBbkFd1DeLl333VeC5TgUCTeTkIyv/pJtLYxhDJe'),
(38, 'paramjit', 'param@param.com', '$2y$10$N62NGgcLSU3IsoCzCOEJc.zLtF/ZUnThPoilSzfJjiENlbB59nYZS'),
(39, 'tom', 'tom@gmail.com', '$2y$10$E08Xr15yx5YWrtoY58BF6unDSnvNwdS9Sw2Zyj5nsThxkGBscXwDq');

-- --------------------------------------------------------

--
-- Table structure for table `plannergo_workspace`
--

CREATE TABLE `plannergo_workspace` (
  `workspaceid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `userid` int(11) NOT NULL,
  `creationdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plannergo_workspace`
--

INSERT INTO `plannergo_workspace` (`workspaceid`, `title`, `description`, `userid`, `creationdate`) VALUES
(20, 'first workspace', 'this is my first workspace', 37, '2022-11-22'),
(21, 'second ', 'second workspace', 37, '2022-11-22'),
(22, 'Project Management', 'Discussion', 39, '2022-11-22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `plannergo_notes`
--
ALTER TABLE `plannergo_notes`
  ADD PRIMARY KEY (`notesid`);

--
-- Indexes for table `plannergo_users`
--
ALTER TABLE `plannergo_users`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `plannergo_workspace`
--
ALTER TABLE `plannergo_workspace`
  ADD PRIMARY KEY (`workspaceid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `plannergo_notes`
--
ALTER TABLE `plannergo_notes`
  MODIFY `notesid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `plannergo_users`
--
ALTER TABLE `plannergo_users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `plannergo_workspace`
--
ALTER TABLE `plannergo_workspace`
  MODIFY `workspaceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
