<!-- create_note.php is used to create a Note in user's workspace -->
<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';

$workspaceid = $_GET['workspaceid'];
$email = $row['email'];
$errors = array();
$notestitle = $_POST['notestitle'] ?? null;
$notesdescription = $_POST['notesdescription'] ?? null;
$wid = $_POST['wid'] ?? null;

if (isset($_POST['notes-submit'])) { //only do this code if the form has been submitted

  //sanitize input variables
  $notestitle = filter_var($notestitle, FILTER_SANITIZE_STRING);
  $notesdescription = filter_var($notesdescription, FILTER_SANITIZE_STRING);
  
  //validate user has entered a title
  if (!isset($notestitle) || strlen($notestitle) === 0 ) {
    $errors['notestitle'] = true;
  }

  if (!isset($notesdescription) || strlen($notesdescription) === 0 ) {
    $errors['notesdescription'] = true;
  }


  if (count($errors) === 0) {
    
    $query="insert into `plannergo_notes` (title,description,userid,workspaceid,creationdate) values(?, ?, ?, ?,NOW())";
    $stmt=$pdo->prepare($query)->execute([$notestitle,$notesdescription,$userid,$wid]);

    $notesid=$pdo->lastInsertId();

    header("Location:notes_viewboard.php?workspaceid=$wid");
    exit();
  }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <?php 
    $page_title = "Add Notes";
    include 'metadata.php'; ?>
  </head>

  <!-- Header-->
  <header class="header">
        <?php include 'home_navbar.php';?>
  </header>

  <body>
    <section>
        <div class="form edit-form">
        <form name="notes-form" id="notes-form" method="POST" action="<?=htmlentities($_SERVER['PHP_SELF']);?>" novalidate>
            <div>
                <label for="notestitle">Title <span>*</span></label>
                <input id="notestitle" name="notestitle" type="text"  value="<?=$notestitle?>" required/>
                <span class="error <?=!isset($errors['notestitle']) ? 'hidden' : "";?>">enter a valid Title for your Note</span>
            </div>
            <div>
                <label for="notesdescription">Description <span>*</span></label>
                <input id="notesdescription" name="notesdescription" type="text"  value="<?=$notesdescription?>" required/>
                <span class="error <?=!isset($errors['notesdescription']) ? 'hidden' : "";?>">enter a valid Description for your Note</span>
            </div>
            <input id="wid" name="wid" type="text"  value="<?=$workspaceid?>" hidden/>
            <div>
                <button id="notes-submit" name="notes-submit" class="submit">Create Note</button>
            </div>
          </form>
    </section>
    </body>

    <!--Footer-->
    <?php include '../includes/footer.php'; ?>

</html>