<!-- delete_workspace.php is used for deleting a particular workspace in user's account -->

<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';

$workspaceid = $_GET['workspaceid'];
$query="DELETE FROM `plannergo_workspace` where workspaceid = ?";
$stmt=$pdo->prepare($query);
$stmt->execute([$workspaceid]);

$query="DELETE FROM `plannergo_notes` where workspaceid = ?";
$stmt=$pdo->prepare($query);
$stmt->execute([$workspaceid]);

header("Location:account.php");
exit();

?>

