
<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';

$notesid = $_GET['notesid'];

// $query1="select `workspaceid` from `plannergo_notes` WHERE notesid = ? ";
//              $stmt=$pdo->prepare($query);
//              $stmt->execute([$notesid]);
//              foreach($stmt as $row):
//                $workspaceid=$row['workspaceid']; 
            

$query2="DELETE FROM `plannergo_notes` where notesid = ?";
$stmt=$pdo->prepare($query);
$stmt->execute([$notesid]);


header("Location:account.php");
exit();

?>