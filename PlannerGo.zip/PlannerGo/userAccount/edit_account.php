<!-- editaccount.php is used for editing user's account -->
<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';
$email = $row['email'];

$errors = array();
$newusername = $_POST['username'] ?? null;
$newemail = $_POST['email'] ?? null;

if (isset($_POST['edit-submit'])) { //only do this code if the form has been submitted

  //sanitize input variables
  $newusername = filter_var($newusername, FILTER_SANITIZE_STRING);
  $newemail = filter_var($newemail, FILTER_SANITIZE_EMAIL);

  //validate user has entered a username
  if (!isset($username) || strlen($username) === 0  ||  !preg_match("/^[a-zA-Z][a-zA-Z0-9_]*$/",$username)) {
      $errors['username'] = true;
  }
  
  //validate user exists or not
  $query = "SELECT username FROM `plannergo_users`";
  $stmt = $pdo->query($query);
  foreach ($stmt as $row):
      if($newusername===$row['username'] && $newusername!==$username){
          $errors['same_username'] = true;
      }
  endforeach;


  //validate email address
  if (!isset($newemail) || strlen($newemail) === 0 || !filter_var($newemail, FILTER_VALIDATE_EMAIL)) {
      $errors['email'] = true;
  }

  //only do this if there weren't any errors
  if (count($errors) === 0) {

      $query="UPDATE `plannergo_users` SET username = ?, email = ? WHERE userid = ?";
      $stmt=$pdo->prepare($query)->execute([$newusername,$newemail,$userid]);
 
      header("Location:edit_account.php");
      exit();
  }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <?php 
    $page_title = "Edit Account";
    include 'metadata.php'; ?>
  </head>
  
  <!-- Header-->
  <header class="header">
        <?php include 'home_navbar.php';?>
  </header>

  <body>
    <section>
        <div class="form edit-form">
          <form name="edit-form" id="edit-form" method="POST" action="<?=htmlentities($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data" novalidate>
            <div>
                <label for="username">Change Username <span>*</span></label>
                <input id="username" name="username" type="text" placeholder="must start with a letter, can contain digits and underscore" value="<?=$username?>" required/>
                <span class="error <?=!isset($errors['username']) ? 'hidden' : "";?>">enter a valid username</span>
                <span class="error <?=!isset($errors['same_username']) ? 'hidden' : "";?>">this username already exists</span>
            </div>
            <div>
                <label for="email">Change Email Address <span>*</span></label>
                <input id="email" name="email" type="email" placeholder="must contain @ and ." value="<?=$email?>" required/>
                <span class="error <?=!isset($errors['email']) ? 'hidden' : "";?>">enter a valid email address</span>
            </div>
            <div>
                <button id="edit-submit" name="edit-submit" class="submit">Submit</button>
            </div>
          </form>
        </div>
    </section>
    </body>

    <!--Footer-->
    <?php include '../includes/footer.php'; ?>
    
</html>