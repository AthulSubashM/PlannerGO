<!-- delete_account.php is used for deleting user's account with all its save data -->
<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';

$query="DELETE FROM `plannergo_users` where userid = ?";
$stmt=$pdo->prepare($query);
$stmt->execute([$userid]);

$query="select workspaceid FROM `plannergo_workspace` where userid = ?";
$stmt=$pdo->prepare($query);
$stmt->execute([$userid]);
$row=$stmt->fetch();
$workspaceid = $row['workspaceid'];

$query="DELETE FROM `plannergo_workspace` where workspaceid = ?";
$stmt=$pdo->prepare($query);
$stmt->execute([$workspaceid]);

$query="DELETE FROM `plannergo_notes` where workspaceid = ?";
$stmt=$pdo->prepare($query);
$stmt->execute([$workspaceid]);

header("Location:../index.php");
exit();

?>

