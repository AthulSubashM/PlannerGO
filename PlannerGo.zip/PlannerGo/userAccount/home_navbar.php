<!-- home_navbar.php is top navigation bar in user's account dashboard -->

<a href="../index.php"><img class="logo" src="../img/logo.png" alt="logo" alt="PlannerGo icon"></a>


        <!--Navigation-->
        <ul class="nav">
            <li><a href="account.php">Hi <?=$username?></a></li>
            <li><a class="<?=strcmp($page_title,"Home")==0 ? 'activelink' : ''?>" href="../index.php">Home</a></li>
            <li><a class="<?=strcmp($page_title,"Workspace")==0 ? 'activelink' : ''?>" href="create_workspace.php">Create Workspace</a></li>
            <li><a class="<?=strcmp($page_title,"Calendar")==0 ? 'activelink' : ''?>" href="calendar.php">Calendar</a></li>
        </ul>

        <!--Account Features-->
       <ul class="reg">
            <li ><a class="<?=strcmp($page_title,"Edit Account")==0 ? 'activelink' : ''?>" href="edit_account.php">Edit</a></li>
            <li ><a class="<?=strcmp($page_title,"Change Password")==0 ? 'activelink' : ''?>" href="change_password.php">Security</a></li>
            <li><a class="<?=strcmp($page_title,"Delete Account")==0 ? 'activelink' : ''?>" href="delete_account.php" onclick="return confirm('Are You sure you want to delete your Account?');">Delete</a></li>
            <li><a class="<?=strcmp($page_title,"Logout")==0 ? 'activelink' : ''?>" href="logout.php" onclick="return confirm('Are You sure you want to Logout?');">Logout</a></li>
       </ul> 

     