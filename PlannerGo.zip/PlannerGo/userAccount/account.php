<!-- account.php is default dashboard view of a logged in user, it displays workspaces created-->
<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';
$email = $row['email'];

?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <?php 
    $page_title = "User Dashboard";
    include 'metadata.php'; ?>
  </head>

  <!-- Header-->
  <header class="header">
        <?php include 'home_navbar.php';?>
  </header>

  <body>
    <section class="dashboard">
          <!--Workspaces-->
          <div class="workspaces workspace-para">
            <h3>Your Workspaces</h3>
          </div>
            <?php 
             $query="select * from `plannergo_workspace` WHERE userid = ? ";
             $stmt=$pdo->prepare($query);
             $stmt->execute([$userid]);
             foreach($stmt as $row):
               $workspaceid=$row['workspaceid']; ?>
               <div class="each-workspace">
                  <a href="notes_viewboard.php?workspaceid=<?=$workspaceid?>"><p id="title"><?=$row['title']?></p>
                  <p id="description"><?=$row['description']?></p></a>
                  <a  href="delete_workspace.php?workspaceid=<?=$workspaceid?>">delete this workspace</a>
               </div>
              <?php endforeach; ?>
    </section>
    </body>

    <!--Footer-->
    <?php include '../includes/footer.php'; ?>

</html>
