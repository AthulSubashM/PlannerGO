<!-- logout.php is used to logout a particular user -->
<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';
session_destroy();
header("Location:../index.php");
exit();
?>
