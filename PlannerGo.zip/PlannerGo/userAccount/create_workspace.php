<!-- create_workspace.php creates Workspace in User Account -->
<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';

$errors = array();
$title = $_POST['title'] ?? null;
$description = $_POST['description'] ?? null;

if (isset($_POST['workspace-submit'])) { //only do this code if the form has been submitted

  //sanitize input variables
  $title = filter_var($title, FILTER_SANITIZE_STRING);
  $description = filter_var($description, FILTER_SANITIZE_STRING);
  
  //validate user has entered a title
  if (!isset($title) || strlen($title) === 0 ) {
    $errors['title'] = true;
  }

  if (!isset($description) || strlen($description) === 0 ) {
    $errors['description'] = true;
  }


  if (count($errors) === 0) {
    
    $query="insert into `plannergo_workspace` (title,description,userid,creationdate) values(?, ?, ?,NOW())";
    $stmt=$pdo->prepare($query)->execute([$title,$description,$userid]);

    $workspaceid=$pdo->lastInsertId();

    header("Location:account.php");
    exit();
  }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <?php 
    $page_title = "Create Workspace";
    include 'metadata.php'; ?>
  </head>

  <!-- Header-->
  <header class="header">
        <?php include 'home_navbar.php';?>
  </header>

  <body>
    <section>
        <div class="form edit-form">
        <form name="workspace-form" id="workspace-form" method="POST" action="<?=htmlentities($_SERVER['PHP_SELF']);?>" novalidate>
            <div>
                <label for="title">Title <span>*</span></label>
                <input id="title" name="title" type="text"  value="<?=$title?>" required/>
                <span class="error <?=!isset($errors['title']) ? 'hidden' : "";?>">enter a valid Title for your Workspace</span>
            </div>
            <div>
                <label for="description">Description <span>*</span></label>
                <input id="description" name="description" type="text"  value="<?=$description?>" required/>
                <span class="error <?=!isset($errors['description']) ? 'hidden' : "";?>">enter a valid Description for your Sheet</span>
            </div>
            <div>
                <button id="workspace-submit" name="workspace-submit" class="submit">Create Workspace</button>
            </div>
          </form>
    </section>
    </body>

    <!--Footer-->
    <?php include '../includes/footer.php'; ?>

</html>