<!-- metadata.php is general head section for userAccount folder php files -->
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>PlannerGo - <?=$page_title?></title>
<link rel="stylesheet" href="../styles/master.css"/>