<!-- changepassword.php is used for changing user's password -->
<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';

$oldpassword = $_POST['oldpassword'] ?? null;
$newpassword1 = $_POST['newpassword1'] ?? null;
$newpassword2 = $_POST['newpassword2'] ?? null;
$errors = array();

if (isset($_POST['changepassword-submit'])) {

  $oldpassword = filter_var($oldpassword, FILTER_SANITIZE_STRING);
  $newpassword1 = filter_var($newpassword1, FILTER_SANITIZE_STRING);
  $newpassword2 = filter_var($newpassword2, FILTER_SANITIZE_STRING);

  //checks for errors in password
  if (!isset($newpassword1) || (strlen($newpassword1) <= 8 )){
    $errors['password_syntax1'] = true;
  }
  if(!isset($newpassword2) || (strlen($newpassword2) <= 8 )){
    $errors['password_syntax2'] = true;
  }
  if($newpassword1!==$newpassword2){
    $errors['password_notmatch'] = true;
  }
  if(!password_verify($oldpassword, $row['password'])){
    $errors['login'] = true;
  }

  if (count($errors) === 0) {
    $hashedpassword = password_hash($newpassword1, PASSWORD_DEFAULT);
    $query="UPDATE `plannergo_users` SET password = ? WHERE userid = ? ";
    $stmt=$pdo->prepare($query);
    $stmt->execute([$hashedpassword, $userid]);
    header("Location:change_password.php");
    exit();
  }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <?php 
    $page_title = "Change Password";
    include 'metadata.php'; ?>
  </head>

  <!-- Header-->
  <header class="header">
        <?php include 'home_navbar.php';?>
  </header>

  <body>
    <section>
        <div class="form edit-form">
        <form name="changepassword-form" id="changepassword-form" method="POST" action="<?=htmlentities($_SERVER['PHP_SELF']);?>"  novalidate>
            <div>
                <label for="oldpassword">Enter the present Password <span>*</span></label>
                <input id="oldpassword" name="oldpassword" type="password"  value="<?=$oldpassword?>" required/>
                <span class="error <?=!isset($errors['login']) ? 'hidden' : "";?>">this password is incorrect</span>
            </div>
            <div>
                <label for="newpassword1">Enter a new Password <span>*</span></label>
                <input id="newpassword1" name="newpassword1" type="password"  value="<?=$newpassword1?>" required/>
                <span class="error <?=!isset($errors['password_syntax1']) ? 'hidden' : "";?>">enter a password with more than 8 characters</span>
            </div>
            <div>
                <label for="newpassword2">Re-enter the new Password <span>*</span></label>
                <input id="newpassword2" name="newpassword2" type="password"  value="<?=$newpassword2?>" required/>
                <span class="error <?=!isset($errors['password_syntax2']) ? 'hidden' : "";?>">enter a password with more than 8 characters</span>
                <span class="error <?=!isset($errors['password_notmatch']) ? 'hidden' : "";?>">the two new Passwords do not match</span>
            </div>
            <div>
                <button id="changepassword-submit" name="changepassword-submit" class="submit">Submit</button>
            </div>
          </form>
        </div>
    </section>
    </body>

    <!--Footer-->
    <?php include '../includes/footer.php'; ?>
    
</html>