<!-- notes_viewboard.php displays created notes in a particular workspace of user -->
<?php
include '../includes/library.php';
include '../includes/databaseQuery.php';
$workspaceid = $_GET['workspaceid'];
$email = $row['email'];

?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <?php 
    $page_title = "Notes Viewboard";
    include 'metadata.php'; ?>
  </head>

  <!-- Header-->
  <header class="header">
        <?php include 'home_navbar.php';?>
  </header>

  <body>
    <section class="dashboard">
            <?php 
             $query="select `title` from `plannergo_workspace` WHERE workspaceid = ? ";
             $stmt=$pdo->prepare($query);
             $stmt->execute([$workspaceid]);
             foreach($stmt as $row):?>
               <div class="workspaces workspace-para">
                  <h3>Workspace - <?=$row['title']?></h3>
                  <a href="create_note.php?workspaceid=<?=$workspaceid?>">Add Note</a>
               </div>
              <?php endforeach;
             $query="select * from `plannergo_notes` WHERE workspaceid = ? ";
             $stmt=$pdo->prepare($query);
             $stmt->execute([$workspaceid]);
             foreach($stmt as $row): ?>
               <div class="each-workspace">
                  <p id="title"><?=$row['title']?></p>
                  <p id="description"><?=$row['description']?></p>
                  
               </div>
              <?php endforeach; ?>
    </section>
    </body>

    <!--Footer-->
    <?php include '../includes/footer.php'; ?>

</html>
