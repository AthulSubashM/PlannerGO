<!-- about.php is used for displaying general website information -->
<?php 
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <?php 
    $page_title = "About";
    include 'includes/metadata.php'; ?>
  </head>

  <!-- Header-->
  <header class="header">
        <?php include 'includes/navbar.php';?>
    </header>

  <body>
      <section class="form contact">            
          <p>PlannerGo is a great website to handle all your notetaking activities</p>
          <p>Paramjit Singh & Tobi are the seniors developers of the website</p>
          <p>The website is a course deliverable for the Project Management course offered at Trent University, Peterborough</p>
      </section>
  </body>

  <!--Footer-->
  <?php include 'includes/footer.php'; ?>

</html>
