<!-- signup.php is used used for user registration and signup -->
<?php
include 'includes/library.php';

$pdo = connectDB();

$errors = array(); 
$username = $_POST['username'] ?? null;
$email = $_POST['email'] ?? null;
$password = $_POST['password'] ?? null;


if (isset($_POST['signup-submit'])) { //only do this code if the form has been submitted

    //sanitize input variables
    $username = filter_var($username, FILTER_SANITIZE_STRING);
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    $password = filter_var($password, FILTER_SANITIZE_STRING);

    //validate user has entered a username
    if (!isset($username) || strlen($username) === 0  ||  !preg_match("/^[a-zA-Z][a-zA-Z0-9_]*$/",$username)) {
        $errors['username'] = true;
    }
    
    //validate user exists or not
    $query = "SELECT username FROM `plannergo_users`";
    $stmt = $pdo->query($query);
    
    foreach ($stmt as $row):
        if($username===$row['username']){
            $errors['same_username'] = true;
        }
    endforeach;


    //validate email address
    if (!isset($email) || strlen($email) === 0 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = true;
    }

    //validate password
    if (!isset($password) || strlen($password) <= 8) {
        $errors['password'] = true;
    }


    //only do this if there weren't any errors
    if (count($errors) === 0) {

        $hashedpassword = password_hash($password, PASSWORD_DEFAULT);
        $query="insert into `plannergo_users` (username,email,password) values(?, ?, ?)";
        $stmt=$pdo->prepare($query)->execute([$username,$email,$hashedpassword]);

        $query="select userid from `plannergo_users` WHERE username = ? ";
        $stmt=$pdo->prepare($query);
        $stmt->execute([$username]);
        $row=$stmt->fetch();
        $userid = $row['userid'];

        session_start();
        $_SESSION['userid'] = $userid;
        
        //send the user to the user account page
        header("Location:userAccount/account.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <?php 
    $page_title = "Signup";
    include 'includes/metadata.php'; ?>
  </head>

  <!-- Header-->
  <header class="header">
        <?php include 'includes/navbar.php';?>
  </header> 

  <body>
      <section class="form">
          <form name="signup-form" id="signup-form" method="POST" action="<?=htmlentities($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data" novalidate>
            <div>
                <label for="username">Username: <span>*</span></label>
                <input id="username" name="username" type="text" placeholder="must start with a letter, can contain digits and underscore" value="<?=$username?>" required/>
                <span class="error <?=!isset($errors['username']) ? 'hidden' : "";?>">enter a valid username</span>
                <span class="error <?=!isset($errors['same_username']) ? 'hidden' : "";?>">this username already exists</span>
            </div>
            <div>
                <label for="email">Email Address: <span>*</span></label>
                <input id="email" name="email" type="email" placeholder="must contain @ and ." value="<?=$email?>" required/>
                <span class="error <?=!isset($errors['email']) ? 'hidden' : "";?>">enter a valid email address</span>
            </div>
            <div>
                <label for="password">Password: <span>*</span></label>
                <input id="password" name="password" type="password" placeholder="must be greater than 8 characters" value="<?=$password?>" required/>
                <span class="error <?=!isset($errors['password']) ? 'hidden' : "";?>">enter a password with more than 8 characters</span>
            </div>
            <div>
                <button id="signup-submit" name="signup-submit" class="submit">Submit</button>
            </div>
          </form>
      </section> 
    </body>

    <!--Footer-->
    <?php include 'includes/footer.php'; ?>

</html>