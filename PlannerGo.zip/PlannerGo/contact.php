<!-- contact.php is used for displaying general contact info -->
<?php 
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <?php 
    $page_title = "Contact";
    include 'includes/metadata.php'; ?>
  </head>

  <!-- Header-->
  <header class="header">
        <?php include 'includes/navbar.php';?>
    </header>

  <body>
      <section class="form contact">            
          <p>PlannerGo is a great website to handle all your notetaking activities</p>
          <p>You can reach us by emailing at help@plannergo.com or calling us at 99998-78889</p>
          <p>We shall contact you back within 2-4 hrs depending on our executives' availaibilty</p>
      </section>
  </body>

  <!--Footer-->
  <?php include 'includes/footer.php'; ?>

</html>
