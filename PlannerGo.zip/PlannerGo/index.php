<!-- index.php is the home page of PlannerGo -->
<?php ?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <?php 
    $page_title = "Home";
    include 'includes/metadata.php';
    ?>
    </head>

    <!-- Header-->
    <header class="header">
        <?php include 'includes/navbar.php';?>
    </header>

    <!-- Body-->

    <body>

        <!--Banner-->
        <div class="banner">
            <h2> Welcome to PlannerGO</h2>
            <p class="intro">
                PlannerGo is a webapp capable of creating workspaces, taking notes and scheduling events             
            </p>
        </div>
        <div>
            <img src=img/home.png width=100% height=100%>
        </div>


    </body>

    <!--Footer-->
    <?php include 'includes/footer.php'; ?>

</html>