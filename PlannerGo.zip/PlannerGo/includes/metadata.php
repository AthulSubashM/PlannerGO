<!-- metadata.php contains head section for files like index, login, etc -->
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>PlannerGo - <?=$page_title?></title>
<link type="text/css" rel="stylesheet" href="styles/master.css"/>
<link defer rel="stylesheet" href="styles/master.css"/>
<script defer src="scripts/index.js"></script>
