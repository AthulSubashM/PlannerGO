<?php
// databaseQuery.php contains database query which is used in almost every php file  

session_start();
$userid = $_SESSION['userid'];
$pdo = connectDB();
$query="select * from `plannergo_users` where userid = ?";
$stmt=$pdo->prepare($query);
$stmt->execute([$userid]);
$row=$stmt->fetch();
$username = $row['username'];