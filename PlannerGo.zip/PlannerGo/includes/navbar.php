<!-- navbar.php contains navigation bar which we see on home page -->
<a href="index.php"><img class="logo" src="./img/logo.png" alt="logo" alt="PlannerGo icon"></a>

        <!--Navigation-->
        <ul class="nav">
            <li><a class="<?=strcmp($page_title,"Home")==0 ? 'activelink' : ''?>" href="index.php">Home</a></li>
            <li class="login"><a class="<?=strcmp($page_title,"Login")==0 ? 'activelink' : ''?>" href="login.php">Login</a></li>
            <li class="signup"><a class="<?=strcmp($page_title,"SignUp")==0 ? 'activelink' : ''?>" href="signup.php">Signup</a></li>
        </ul>

