<!-- footer.php contains footer part of the site -->
<footer>
        <h5 class="footerName">PlannerGO</h5>
            <p class="footLink"><a href="/PlannerGo/index.php">Home</a> | <a href="/PlannerGo/contact.php">Contact us</a> | <a href="/PlannerGo/about.php">About</a> </p>
            <p class="copyright">Copyright &copy; 2022 </p>
</footer>